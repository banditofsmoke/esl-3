import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, BookOpen } from "lucide-react"
import { notFound } from "next/navigation"

// Import the categories data
import { categories } from "../../data/level-4-content"

export default function CategoryPage({ params }: { params: { category: string } }) {
  const { category: categoryId } = params

  // Find the category
  const category = categories.find((cat) => cat.id === categoryId)

  if (!category) {
    notFound()
  }

  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <Link href="/level-4" className="mb-8 inline-flex items-center gap-2 text-slate-600 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        <span>Back to Level 4 Resources</span>
      </Link>

      <div className="mb-12 space-y-4">
        <div className="flex items-center gap-2">
          <Badge className="bg-slate-200 text-slate-800 hover:bg-slate-200">Level 4</Badge>
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">{category.title}</h1>
        </div>
        <p className="max-w-[800px] text-slate-700 md:text-xl">{category.description}</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {category.articles.map((article) => (
          <Card key={article.id} className="flex flex-col">
            <CardHeader>
              <div className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-slate-800" />
                <CardTitle className="text-lg">{article.title}</CardTitle>
              </div>
              <CardDescription>
                {article.tags.map((tag, i) => (
                  <span key={i}>
                    {tag}
                    {i < article.tags.length - 1 ? " • " : ""}
                  </span>
                ))}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <p className="text-sm text-slate-700">{article.description}</p>
            </CardContent>
            <CardFooter>
              <Link href={`/level-4/${categoryId}/${article.id}`} className="w-full">
                <Button className="w-full bg-slate-800 hover:bg-slate-700">Read Article</Button>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
