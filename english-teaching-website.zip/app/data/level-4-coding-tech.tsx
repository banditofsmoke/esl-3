import type React from "react"

// Helper function to create article content
const createArticleContent = (content: React.ReactNode) => content

// Define the coding tech articles
const codingTechArticles = [
  {
    id: "coding-basics",
    title: "Programming Fundamentals for Beginners",
    description:
      "An accessible introduction to core programming concepts that form the foundation of all coding languages.",
    tags: ["Programming", "Coding", "Fundamentals"],
    readingTime: "14 minutes",
    content: createArticleContent(
      <>
        <h2>Introduction: Why Learn to Code?</h2>
        <p>
          In today's digital world, understanding the basics of programming has become an increasingly valuable
          skill—regardless of your career aspirations. Learning to code isn't just for future software developers; it's
          a form of digital literacy that can benefit students pursuing virtually any field.
        </p>
        <p>
          Programming teaches you to think logically, break down complex problems into manageable parts, and create
          step-by-step solutions. These computational thinking skills transfer to many areas of life and work, from
          analyzing data for a science project to organizing a community event.
        </p>
        {/* More content omitted for brevity */}
      </>,
    ),
  },
  {
    id: "web-development",
    title: "Introduction to Web Development",
    description:
      "Understanding the technologies that power the web and how to create your own simple websites and applications.",
    tags: ["Web Development", "HTML", "CSS", "JavaScript"],
    readingTime: "15 minutes",
    content: createArticleContent(
      <>
        <h2>Introduction to Web Development</h2>
        <p>
          Web development is the process of building and maintaining websites and web applications. It's a creative
          field that combines design, programming, and problem-solving to create the digital experiences we use every
          day.
        </p>

        <h2>The Building Blocks of the Web</h2>
        <p>Modern websites are built using three core technologies:</p>

        <h3>HTML: The Structure</h3>
        <p>
          HTML (HyperText Markup Language) provides the basic structure of websites. It's like the skeleton of a web
          page, defining elements like headings, paragraphs, images, links, and more.
        </p>
        <pre>
          {`<!DOCTYPE html>
<html>
  <head>
    <title>My First Webpage</title>
  </head>
  <body>
    <h1>Hello, World!</h1>
    <p>This is my first webpage.</p>
    <img src="profile.jpg" alt="My profile picture">
    <a href="https://example.com">Visit Example.com</a>
  </body>
</html>`}
        </pre>

        <h3>CSS: The Style</h3>
        <p>
          CSS (Cascading Style Sheets) controls the appearance and layout of web pages. It's like the clothing and
          makeup that makes the skeleton look presentable and unique.
        </p>
        <pre>
          {`/* Style for the heading */
h1 {
  color: blue;
  font-size: 24px;
  text-align: center;
}

/* Style for paragraphs */
p {
  color: #333333;
  font-family: Arial, sans-serif;
  line-height: 1.5;
}`}
        </pre>

        <h3>JavaScript: The Behavior</h3>
        <p>
          JavaScript adds interactivity to websites. It allows web pages to respond to user actions, update content
          dynamically, and create complex functionality.
        </p>
        <pre>
          {`// When the button is clicked, show an alert
document.getElementById("myButton").addEventListener("click", function() {
  alert("Button was clicked!");
});

// Change the text of a paragraph
function updateText() {
  document.getElementById("demo").innerHTML = "Text has been updated!";
}`}
        </pre>

        <h2>The Web Development Process</h2>

        <h3>1. Planning</h3>
        <p>
          Before writing any code, web developers plan the website's purpose, target audience, content, and
          functionality. This often involves creating wireframes (simple visual guides) and site maps.
        </p>

        <h3>2. Design</h3>
        <p>
          Next comes the visual design, where developers or designers create mockups showing how the website will look.
          This includes color schemes, typography, layout, and overall aesthetic.
        </p>

        <h3>3. Development</h3>
        <p>
          This is where the actual coding happens. Developers write HTML, CSS, and JavaScript to build the website
          according to the design and functionality requirements.
        </p>

        <h3>4. Testing</h3>
        <p>
          The website is tested across different browsers, devices, and screen sizes to ensure it works correctly and
          looks good everywhere. Bugs and issues are identified and fixed.
        </p>

        <h3>5. Deployment</h3>
        <p>
          Once testing is complete, the website is uploaded to a web server and made available to the public. This
          involves setting up domain names, hosting, and sometimes databases.
        </p>

        <h3>6. Maintenance</h3>
        <p>
          Websites require ongoing maintenance to keep content fresh, fix bugs, improve security, and add new features
          as needed.
        </p>

        <h2>Types of Web Development</h2>

        <h3>Front-End Development</h3>
        <p>
          Front-end developers focus on what users see and interact with directly. They work with HTML, CSS, and
          JavaScript to create the user interface and experience.
        </p>

        <h3>Back-End Development</h3>
        <p>
          Back-end developers work on the server side, handling data storage, security, and application logic. They use
          languages like Python, PHP, Ruby, Java, or Node.js, along with databases like MySQL or MongoDB.
        </p>

        <h3>Full-Stack Development</h3>
        <p>
          Full-stack developers have skills in both front-end and back-end development, allowing them to work on all
          aspects of a web project.
        </p>

        <h2>Getting Started with Web Development</h2>

        <h3>Learning Resources</h3>
        <ul>
          <li>Online platforms like freeCodeCamp, Codecademy, and MDN Web Docs offer free tutorials and courses</li>
          <li>
            YouTube channels such as Traversy Media, The Net Ninja, and Web Dev Simplified provide video tutorials
          </li>
          <li>Books like "HTML and CSS: Design and Build Websites" by Jon Duckett are excellent for beginners</li>
        </ul>

        <h3>Essential Tools</h3>
        <ul>
          <li>Text editor or IDE: Visual Studio Code, Sublime Text, or Atom</li>
          <li>Web browsers with developer tools: Chrome, Firefox, or Edge</li>
          <li>Version control: Git and GitHub for tracking changes and collaborating</li>
        </ul>

        <h3>First Projects</h3>
        <p>Start with simple projects to build your skills:</p>
        <ul>
          <li>Personal portfolio website</li>
          <li>To-do list application</li>
          <li>Weather app using a public API</li>
          <li>Blog with basic content management</li>
        </ul>

        <h2>Web Development in the Modern Era</h2>

        <h3>Responsive Design</h3>
        <p>
          With the variety of devices used to access the web, responsive design ensures websites look good and function
          well on screens of all sizes, from smartphones to desktop monitors.
        </p>

        <h3>Frameworks and Libraries</h3>
        <p>Modern web development often uses frameworks and libraries to speed up development and add functionality:</p>
        <ul>
          <li>Front-end frameworks: React, Vue.js, Angular</li>
          <li>CSS frameworks: Bootstrap, Tailwind CSS</li>
          <li>Back-end frameworks: Express.js (Node.js), Django (Python), Ruby on Rails</li>
        </ul>

        <h3>Web Accessibility</h3>
        <p>
          Creating websites that are accessible to all users, including those with disabilities, is an important aspect
          of modern web development. This includes proper HTML structure, alternative text for images, keyboard
          navigation, and more.
        </p>

        <h2>Conclusion</h2>
        <p>
          Web development is a dynamic and rewarding field that combines creativity with technical skills. Whether
          you're interested in pursuing it as a career or just want to build your own website, the skills you learn will
          be valuable in our increasingly digital world.
        </p>

        <p>
          The web continues to evolve, with new technologies and approaches emerging regularly. By understanding the
          fundamentals and keeping up with trends, you can create websites and applications that are both functional and
          delightful to use.
        </p>
      </>,
    ),
  },
  {
    id: "data-literacy",
    title: "Data Literacy in the Digital Age",
    description:
      "Essential skills for understanding, interpreting, and communicating with data in personal and professional contexts.",
    tags: ["Data", "Analysis", "Visualization"],
    readingTime: "12 minutes",
  },
  {
    id: "cybersecurity",
    title: "Cybersecurity Essentials",
    description:
      "Practical knowledge for protecting your digital identity, personal information, and devices from cyber threats.",
    tags: ["Security", "Privacy", "Digital Safety"],
    readingTime: "13 minutes",
  },
  {
    id: "tech-careers",
    title: "Exploring Technology Careers",
    description:
      "Overview of diverse career paths in technology that don't necessarily require advanced programming skills.",
    tags: ["Careers", "Technology", "Industry"],
    readingTime: "11 minutes",
  },
  {
    id: "digital-creativity",
    title: "Digital Tools for Creativity",
    description:
      "Leveraging technology for creative expression through digital art, design, music, video, and storytelling.",
    tags: ["Creativity", "Digital Media", "Tools"],
    readingTime: "10 minutes",
  },
]

// Export the array
export { codingTechArticles }
