import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, BookOpen } from "lucide-react"
import SummarySubmission from "@/components/summary-submission"

interface StoryPageProps {
  params: {
    storyId: string
  }
}

export default function StoryPage({ params }: StoryPageProps) {
  const { storyId } = params

  // Sample story data for "The Emperor's New Clothes"
  // In a real implementation, you would have all stories or fetch them from an API
  const story = {
    id: "the-emperors-new-clothes",
    title: "The Emperor's New Clothes",
    origin: "Danish",
    author: "Hans Christian Andersen",
    content: [
      'Many years ago, there lived an emperor who cared so much about having the finest clothes that he spent all his money on being well-dressed. He had a different outfit for every hour of the day, and instead of saying, as one might about any other ruler, "The King is in his council chamber," people would say, "The Emperor is in his dressing room."',
      "One day, two swindlers arrived in the city, claiming to be weavers who could make the most magnificent cloth imaginable. Not only were the colors and patterns extraordinarily beautiful, but the clothes made from this material had a special power—they were invisible to anyone who was either incompetent in their job or hopelessly stupid.",
      '"Those would be perfect clothes!" thought the Emperor. "If I wore them, I could discover which of my officials are unfit for their positions, and I could also distinguish the clever from the foolish!" So he gave the two swindlers a large sum of money to start working on the special garments right away.',
      "The swindlers set up two looms and pretended to work, though there was nothing on the looms at all. They requested the finest silk and the most precious gold thread, which they promptly hid in their own bags while they worked diligently at the empty looms, often late into the night.",
      "\"I'd like to know how they're getting on with the cloth,\" the Emperor thought. But he felt slightly uncomfortable when he remembered that those who were unfit for their positions would not be able to see the fabric. He believed, of course, that he had nothing to fear for himself, but still, he thought it would be better to send someone else first to see how the work was progressing.",
      '"I\'ll send my honest old minister to the weavers," the Emperor decided. "He\'ll be the best person to see how the material is coming along. He\'s a sensible man, and no one is more suitable for his job than he is." So the honest old minister went to the room where the two swindlers sat working at the empty looms.',
      "\"Heaven help me!\" thought the old minister, opening his eyes wide. \"I can't see anything at all!\" But he didn't say this out loud. Both swindlers invited him to come closer and asked him if he didn't think the colors and patterns were beautiful. They pointed to the empty looms, and the poor old minister stared as hard as he could, but he couldn't see anything, because there was nothing to see.",
      '"Oh dear," he thought, "am I a fool? Am I unfit for my position? No one can ever know that I couldn\'t see the material." So he praised the fabric he couldn\'t see and assured them of his delight in the beautiful colors and the exquisite pattern.',
      '"Well, we\'re pleased to hear that," said the swindlers, and they proceeded to name all the colors and describe the special pattern. The old minister listened carefully so that he could repeat it all to the Emperor, which is exactly what he did.',
      "The swindlers now asked for more money, more silk, and more gold thread to continue their work. They put it all in their own pockets, and not a single thread ever went into the fabric, though they continued to work at the empty looms.",
      "Soon the Emperor sent another honest official to see how the work was progressing. The same thing happened to him as had happened to the minister. He looked and looked, but since there was nothing on the looms, he couldn't see anything.",
      "\"Isn't it a beautiful piece of fabric?\" asked the swindlers, showing and explaining the magnificent pattern that wasn't there at all. \"I know I'm not stupid,\" the man thought, \"so it must be that I'm unworthy of my good position. That's strange. I mustn't let anyone know this.\" So he praised the material he couldn't see and expressed his enthusiasm for the beautiful colors and patterns.",
      "Eventually, the Emperor himself wished to see the splendid fabric while it was still on the loom. Accompanied by a select group of officials, including the two who had already been there, he went to the two clever swindlers, who were now weaving with all their might, but without a single thread.",
      '"Isn\'t it magnificent?" said the two officials who had been there before. "Your Majesty, look at the colors and the patterns!" And they pointed to the empty looms, each believing that the others could see the fabric.',
      '"What\'s this?" thought the Emperor. "I can\'t see anything! This is terrible! Am I a fool? Am I unfit to be Emperor? This is the most dreadful thing that could happen!" But aloud he said, "Oh, it\'s very beautiful! It has my highest approval!" And he nodded his appreciation as he gazed at the empty looms. Nothing would induce him to say that he couldn\'t see anything.',
      'His whole entourage stared and stared, but no one could see anything, because there was nothing to see. Nevertheless, they all said, just like the Emperor, "Oh, it\'s beautiful!" They advised him to have clothes made from this magnificent material for the grand procession that was soon to take place.',
      '"Magnificent! Excellent! Splendid!" went from mouth to mouth, and everyone was extremely pleased. The Emperor gave each of the swindlers a cross to wear in their buttonholes and the title of "Sir Weaver."',
      'The night before the procession, the swindlers stayed up late, burning more than sixteen candles. People could see they were hard at work, finishing the Emperor\'s new clothes. They pretended to take the fabric off the looms; they cut the air with huge scissors; they sewed with needles without thread; and at last they said, "Now the clothes are ready!"',
      'The Emperor, with his grandest courtiers, went to the swindlers himself, and both swindlers raised their arms as if they were holding something. They said, "These are the trousers! Here is the coat! Here is the cloak!" and so on. "They\'re as light as a spider\'s web! You might almost feel you had nothing on, but that\'s the beauty of them!"',
      '"Yes," agreed all the courtiers, though they could see nothing, for there was nothing to see. "Would Your Imperial Majesty graciously consent to take off your clothes," said the swindlers, "so that we may put the new ones on you, in front of this large mirror?"',
      "The Emperor took off all his clothes, and the swindlers pretended to put each new garment on him, one after the other. They took him around the waist and seemed to be fastening something—that was the train—and the Emperor turned round and round in front of the mirror.",
      '"How well His Majesty looks in the new clothes! How becoming they are!" everyone in the crowd said. "What a design! What colors! These are indeed royal robes!"',
      '"The canopy that is to be carried above Your Majesty in the procession is waiting outside," the chief master of ceremonies reported.',
      '"Well, I\'m ready," the Emperor said. "Don\'t the clothes fit well?" Then he turned around once more in front of the mirror, pretending to study his finery with great care.',
      "The chamberlains who were to carry the train fumbled on the floor, trying to pick it up. They pretended to lift and hold it high. They didn't dare admit they couldn't see anything.",
      "So the Emperor walked in the procession under the beautiful canopy, and all the people in the streets and at the windows said, \"Oh, how fine the Emperor's new clothes are! What a perfect fit! And the colors—how beautiful!\" No one wanted to admit that they couldn't see anything, for that would prove them either unfit for their positions or hopelessly stupid.",
      'None of the Emperor\'s clothes had ever been such a success. "But he doesn\'t have anything on!" a little child said. "Listen to the voice of innocence!" said the child\'s father, and one person whispered to another what the child had said. "A child says he doesn\'t have anything on!"',
      '"He doesn\'t have anything on!" the whole crowd was shouting at last. The Emperor shivered, for he was certain that they were right, but he thought, "I must go through with the procession." So he held himself even more proudly, and the chamberlains walked along holding the train that wasn\'t there at all.',
    ],
    vocabulary: [
      { word: "swindlers", definition: "people who obtain money dishonestly by deceiving others" },
      { word: "incompetent", definition: "not having the necessary skills or ability to do something successfully" },
      { word: "diligently", definition: "in a way that shows care and effort in your work" },
      { word: "proceeded", definition: "continued with a course of action" },
      { word: "exquisite", definition: "extremely beautiful and delicate" },
      { word: "entourage", definition: "a group of people who attend or accompany an important person" },
      { word: "induce", definition: "to persuade or influence someone to do something" },
      { word: "magnificent", definition: "extremely beautiful, elaborate, or impressive" },
      {
        word: "courtiers",
        definition: "people who attend a royal court as companions or advisers to the king or queen",
      },
      { word: "finery", definition: "expensive or impressive clothes" },
      { word: "chamberlains", definition: "officers who manage the household of a monarch or noble person" },
      { word: "canopy", definition: "a covering suspended over a bed, throne, or other piece of furniture" },
    ],
    region: "Europe",
    moral:
      "People often pretend to know or believe things they don't understand out of fear of appearing foolish or incompetent. Sometimes it takes the innocence of a child to speak the simple truth that everyone else is afraid to acknowledge.",
  }

  if (!story) {
    return <div>Story not found</div>
  }

  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <Link href="/level-2" className="mb-8 inline-flex items-center gap-2 text-slate-600 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        <span>Back to Level 2 Stories</span>
      </Link>

      <div className="mb-8 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Badge className="bg-slate-200 text-slate-800 hover:bg-slate-200">Level 2</Badge>
          <Badge className="bg-slate-100 text-slate-800 hover:bg-slate-100">{story.origin} Tale</Badge>
        </div>
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">{story.title}</h1>
        <p className="text-slate-600">By {story.author}</p>
      </div>

      <div className="grid gap-8 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Story
              </CardTitle>
              <CardDescription>Read the story carefully and prepare to write a summary</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                {story.content.map((paragraph, index) => (
                  <p key={index} className="mb-4">
                    {paragraph}
                  </p>
                ))}
                <div className="mt-6 rounded-lg bg-slate-50 p-4">
                  <h3 className="mb-2 font-semibold">Moral of the Story</h3>
                  <p className="italic text-slate-700">{story.moral}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <SummarySubmission level="2" />
        </div>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Vocabulary</CardTitle>
              <CardDescription>Key words from the story</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {story.vocabulary.map((item, index) => (
                  <li key={index} className="rounded-lg border p-3">
                    <div className="font-medium">{item.word}</div>
                    <div className="text-sm text-slate-600">{item.definition}</div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Reading Comprehension</CardTitle>
              <CardDescription>Think about these questions</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="rounded-lg border p-3">
                  <p className="text-sm text-slate-700">
                    Why did the Emperor believe the swindlers' claims about the special cloth?
                  </p>
                </li>
                <li className="rounded-lg border p-3">
                  <p className="text-sm text-slate-700">
                    Why did the officials pretend to see the clothes when there was nothing there?
                  </p>
                </li>
                <li className="rounded-lg border p-3">
                  <p className="text-sm text-slate-700">What does the child's honesty represent in the story?</p>
                </li>
                <li className="rounded-lg border p-3">
                  <p className="text-sm text-slate-700">How does this story relate to situations in real life?</p>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Navigation</CardTitle>
              <CardDescription>Explore more stories</CardDescription>
            </CardHeader>
            <CardFooter>
              <Link href="/level-2" className="w-full">
                <Button variant="outline" className="w-full">
                  All Level 2 Stories
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
