import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  BookOpen,
  Award,
  BookText,
  Clock,
  Star,
  BookMarked,
  Newspaper,
  GraduationCap,
  Brain,
  Coffee,
} from "lucide-react"
import TeacherProfile from "@/components/teacher-profile"
import TeachingMethods from "@/components/teaching-methods"
import PricingPlans from "@/components/pricing-plans"
import PhonicsChart from "@/components/phonics-chart"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-slate-50 to-slate-100">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_500px]">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <Badge className="bg-slate-200 text-slate-800 hover:bg-slate-200">English Learning</Badge>
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  Master English with Wayne Sletcher
                </h1>
                <p className="max-w-[600px] text-slate-700 md:text-xl">
                  Personalized instruction, interactive learning, and cultural understanding. Achieve fluency and
                  confidence in English.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="#phonics">
                  <Button size="lg" className="bg-slate-800 hover:bg-slate-700">
                    Start with Phonics
                  </Button>
                </Link>
                <Link href="/level-1">
                  <Button variant="outline" size="lg">
                    Explore Stories
                  </Button>
                </Link>
              </div>
              <div className="flex items-center gap-4 pt-4">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="inline-block h-8 w-8 rounded-full bg-slate-200 ring-2 ring-white" />
                  ))}
                </div>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <div className="text-sm text-slate-600">Trusted by 500+ students</div>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative h-[350px] w-[350px] sm:h-[400px] sm:w-[400px] lg:h-[450px] lg:w-[450px]">
                <Image
                  src="/placeholder.svg?height=450&width=450"
                  alt="Wayne Sletcher"
                  className="rounde d-lg object-cover"
                  fill
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <TeacherProfile />
        </div>
      </section>

      {/* Teaching Methods Section */}
      <section id="methods" className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
        <div className="container px-4 md:px-6">
          <TeachingMethods />
        </div>
      </section>

      {/* Phonics Chart Section - Level 0 */}
      <section id="phonics" className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <PhonicsChart />
        </div>
      </section>

      {/* Level 1 Preview Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <Badge className="bg-slate-200 text-slate-800 hover:bg-slate-200">Level 1</Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Reading Stories</h2>
              <p className="max-w-[900px] text-slate-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Explore 12 classic fables from around the world, perfect for beginning readers.
              </p>
            </div>
            <div className="grid w-full grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 mt-8">
              {[
                {
                  title: "The Tortoise and the Hare",
                  origin: "Greek",
                  description: "A classic tale about the race between a tortoise and a hare.",
                },
                {
                  title: "The Lion and the Mouse",
                  origin: "African",
                  description: "A small mouse helps a mighty lion, proving that size isn't everything.",
                },
                {
                  title: "The Crow and the Pitcher",
                  origin: "Greek",
                  description: "A thirsty crow uses its intelligence to get water from a pitcher.",
                },
                {
                  title: "The Monkey and the Crocodile",
                  origin: "Indian",
                  description: "A clever monkey outsmarts a hungry crocodile.",
                },
              ].map((story, index) => (
                <Card key={index} className="flex flex-col">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <BookMarked className="h-5 w-5 text-slate-800" />
                      <CardTitle className="text-lg">{story.title}</CardTitle>
                    </div>
                    <CardDescription>{story.origin} Fable</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <p className="text-sm text-slate-700">{story.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Link href={`/level-1/${story.title.toLowerCase().replace(/\s+/g, "-")}`} className="w-full">
                      <Button variant="outline" className="w-full">
                        Read Story
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
            <Link href="/level-1">
              <Button className="mt-6 bg-slate-800 hover:bg-slate-700">View All 12 Stories</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Level 2 Preview Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <Badge className="bg-slate-200 text-slate-800 hover:bg-slate-200">Level 2</Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Intermediate Stories</h2>
              <p className="max-w-[900px] text-slate-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Classic tales from around the world for Grade 4-5 reading levels.
              </p>
            </div>
            <div className="grid w-full grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 mt-8">
              {[
                {
                  title: "The Emperor's New Clothes",
                  origin: "Danish",
                  description: "A vain emperor is tricked by swindlers who promise him invisible clothes.",
                },
                {
                  title: "The Happy Prince",
                  origin: "Irish",
                  description: "A statue of a prince helps the poor people of the city with the help of a swallow.",
                },
                {
                  title: "Aladdin's Lamp",
                  origin: "Middle Eastern",
                  description: "A young man finds a magic lamp containing a genie who grants wishes.",
                },
                {
                  title: "The Legend of Mulan",
                  origin: "Chinese",
                  description: "A young woman disguises herself as a man to take her father's place in the army.",
                },
              ].map((story, index) => (
                <Card key={index} className="flex flex-col">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <BookText className="h-5 w-5 text-slate-800" />
                      <CardTitle className="text-lg">{story.title}</CardTitle>
                    </div>
                    <CardDescription>{story.origin} Tale</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <p className="text-sm text-slate-700">{story.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Link
                      href={`/level-2/${story.title.toLowerCase().replace(/[']/g, "").replace(/\s+/g, "-")}`}
                      className="w-full"
                    >
                      <Button variant="outline" className="w-full">
                        Read Story
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
            <Link href="/level-2">
              <Button className="mt-6 bg-slate-800 hover:bg-slate-700">View All Level 2 Stories</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Level 3 Preview Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <Badge className="bg-slate-200 text-slate-800 hover:bg-slate-200">Level 3</Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Advanced Stories</h2>
              <p className="max-w-[900px] text-slate-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Engaging stories with complex themes for Grade 6-8 reading levels.
              </p>
            </div>
            <div className="grid w-full grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 mt-8">
              {[
                {
                  title: "The Time Traveler",
                  origin: "Science Fiction",
                  description: "A brilliant inventor creates a machine that allows him to travel through time.",
                },
                {
                  title: "The Final Leaf",
                  origin: "American",
                  description:
                    "A young woman believes she will die when the last leaf falls from the vine outside her window.",
                },
                {
                  title: "The Diamond Necklace",
                  origin: "French",
                  description:
                    "A woman borrows an expensive necklace for a party but loses it, with unexpected consequences.",
                },
                {
                  title: "The Hidden Garden",
                  origin: "British",
                  description:
                    "A lonely girl discovers a locked garden and brings it back to life, finding healing in the process.",
                },
              ].map((story, index) => (
                <Card key={index} className="flex flex-col">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-slate-800" />
                      <CardTitle className="text-lg">{story.title}</CardTitle>
                    </div>
                    <CardDescription>{story.origin} Story</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <p className="text-sm text-slate-700">{story.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Link href={`/level-3/${story.title.toLowerCase().replace(/\s+/g, "-")}`} className="w-full">
                      <Button variant="outline" className="w-full">
                        Read Story
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
            <Link href="/level-3">
              <Button className="mt-6 bg-slate-800 hover:bg-slate-700">View All Level 3 Stories</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Level 4 Preview Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <Badge className="bg-slate-200 text-slate-800 hover:bg-slate-200">Level 4</Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">High School Resources</h2>
              <p className="max-w-[900px] text-slate-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Essential knowledge and skills for grades 9-12, including college preparation and technology literacy.
              </p>
            </div>
            <div className="grid w-full grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
              <Card className="flex flex-col">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <GraduationCap className="h-5 w-5 text-slate-800" />
                    <CardTitle>College Preparation</CardTitle>
                  </div>
                  <CardDescription>Navigate the path to higher education</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-slate-700">
                    Comprehensive guides to college applications, essays, scholarships, and making the right college
                    choice for your future.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/level-4/college-prep/college-application" className="w-full">
                    <Button className="w-full bg-slate-800 hover:bg-slate-700">College Application Guide</Button>
                  </Link>
                </CardFooter>
              </Card>

              <Card className="flex flex-col">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-slate-800" />
                    <CardTitle>AI & Machine Learning</CardTitle>
                  </div>
                  <CardDescription>Understanding the AI revolution</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-slate-700">
                    Learn about artificial intelligence fundamentals, ethical considerations, and how AI is transforming
                    education, careers, and society.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/level-4/ai-ml-basics/ai-fundamentals" className="w-full">
                    <Button className="w-full bg-slate-800 hover:bg-slate-700">AI Fundamentals</Button>
                  </Link>
                </CardFooter>
              </Card>

              <Card className="flex flex-col">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-slate-800" />
                    <CardTitle>Life Skills</CardTitle>
                  </div>
                  <CardDescription>Essential knowledge for success</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-slate-700">
                    Develop critical thinking, financial literacy, communication skills, and emotional intelligence for
                    success in college and beyond.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/level-4/life-skills/critical-thinking" className="w-full">
                    <Button className="w-full bg-slate-800 hover:bg-slate-700">Critical Thinking Guide</Button>
                  </Link>
                </CardFooter>
              </Card>
            </div>
            <Link href="/level-4">
              <Button className="mt-6 bg-slate-800 hover:bg-slate-700">View All Level 4 Resources</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Advanced Reading Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <Badge className="bg-slate-200 text-slate-800 hover:bg-slate-200">Advanced</Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Advanced Reading</h2>
              <p className="max-w-[900px] text-slate-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Resources for advanced English learners to further develop reading skills.
              </p>
            </div>
            <div className="grid w-full grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4 mt-8">
              <Card className="flex flex-col">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Newspaper className="h-5 w-5 text-slate-800" />
                    <CardTitle>Engoo Daily News</CardTitle>
                  </div>
                  <CardDescription>Current events for English learners</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-slate-700">
                    Articles on current events written specifically for English learners at various levels, with
                    vocabulary explanations.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link
                    href="https://engoo.com/app/daily-news"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full"
                  >
                    <Button className="w-full bg-slate-800 hover:bg-slate-700">Visit Site</Button>
                  </Link>
                </CardFooter>
              </Card>

              <Card className="flex flex-col">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-slate-800" />
                    <CardTitle>Classic Literature</CardTitle>
                  </div>
                  <CardDescription>Timeless works of English literature</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-slate-700">
                    Reading classic literature helps advanced learners understand cultural references and sophisticated
                    language.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/advanced-reading" className="w-full">
                    <Button className="w-full bg-slate-800 hover:bg-slate-700">Learn More</Button>
                  </Link>
                </CardFooter>
              </Card>

              <Card className="flex flex-col">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <BookText className="h-5 w-5 text-slate-800" />
                    <CardTitle>News Websites</CardTitle>
                  </div>
                  <CardDescription>Current events from reputable sources</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-slate-700">
                    Reading news from reputable sources helps advanced learners stay updated while improving vocabulary.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/advanced-reading" className="w-full">
                    <Button className="w-full bg-slate-800 hover:bg-slate-700">Learn More</Button>
                  </Link>
                </CardFooter>
              </Card>

              <Card className="flex flex-col">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <BookText className="h-5 w-5 text-slate-800" />
                    <CardTitle>Perfect English Grammar</CardTitle>
                  </div>
                  <CardDescription>Comprehensive grammar resource</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-slate-700">
                    Clear explanations and exercises for all aspects of English grammar to help refine grammatical
                    accuracy.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link
                    href="https://www.perfect-english-grammar.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full"
                  >
                    <Button className="w-full bg-slate-800 hover:bg-slate-700">Visit Site</Button>
                  </Link>
                </CardFooter>
              </Card>
            </div>
            <Link href="/advanced-reading">
              <Button className="mt-6 bg-slate-800 hover:bg-slate-700">Explore Advanced Resources</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Levels Section */}
      <section id="start-learning" className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Learning Levels</h2>
              <p className="max-w-[900px] text-slate-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Choose your level and start your English learning journey today.
              </p>
            </div>
            <div className="grid w-full grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-6">
              {[
                {
                  title: "Level 0: Phonics",
                  description: "Master the sounds of English letters and syllables",
                  icon: <BookOpen className="h-10 w-10 text-slate-800" />,
                  features: ["Letter sounds", "Syllable management", "Reading speed", "Pronunciation"],
                  timeframe: "2-4 weeks",
                  link: "/#phonics",
                  grade: "Pre-reading",
                },
                {
                  title: "Level 1: Stories",
                  description: "Read and understand simple stories and fables",
                  icon: <BookMarked className="h-10 w-10 text-slate-800" />,
                  features: ["Basic vocabulary", "Simple sentences", "Reading comprehension", "Summarization"],
                  timeframe: "4-8 weeks",
                  link: "/level-1",
                  grade: "Grades 1-3",
                },
                {
                  title: "Level 2: Intermediate",
                  description: "For those with basic English knowledge looking to improve",
                  icon: <BookText className="h-10 w-10 text-slate-800" />,
                  features: ["Advanced vocabulary", "Complex sentences", "Independent reading", "Detailed feedback"],
                  timeframe: "3 months program",
                  link: "/level-2",
                  grade: "Grades 4-5",
                },
                {
                  title: "Level 3: Advanced",
                  description: "For students ready to tackle more complex themes and vocabulary",
                  icon: <BookOpen className="h-10 w-10 text-slate-800" />,
                  features: ["Complex themes", "Literary analysis", "Critical thinking", "Character development"],
                  timeframe: "3-6 months",
                  link: "/level-3",
                  grade: "Grades 6-8",
                },
                {
                  title: "Level 4: High School",
                  description: "Preparing for college and career with advanced skills",
                  icon: <GraduationCap className="h-10 w-10 text-slate-800" />,
                  features: ["College prep", "Life skills", "AI literacy", "Career readiness"],
                  timeframe: "Self-paced",
                  link: "/level-4",
                  grade: "Grades 9-12",
                },
                {
                  title: "Advanced Resources",
                  description: "For fluent speakers aiming for mastery",
                  icon: <Award className="h-10 w-10 text-slate-800" />,
                  features: ["Current events", "Classic literature", "Academic writing", "Grammar mastery"],
                  timeframe: "Self-paced",
                  link: "/advanced-reading",
                  grade: "College+",
                },
              ].map((level, index) => (
                <Card key={index} className="flex flex-col">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      {level.icon}
                      <CardTitle>{level.title}</CardTitle>
                    </div>
                    <CardDescription>{level.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <div className="mb-2 inline-block rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-medium">
                      {level.grade}
                    </div>
                    <ul className="space-y-2">
                      {level.features.map((feature, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <div className="h-2 w-2 rounded-full bg-slate-800" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 flex items-center gap-2 text-sm text-slate-600">
                      <Clock className="h-4 w-4" />
                      <span>{level.timeframe}</span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href={level.link} className="w-full">
                      <Button className="w-full bg-slate-800 hover:bg-slate-700">Start Now</Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
        <div className="container px-4 md:px-6">
          <PricingPlans />
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-slate-800 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Ready to Master English?</h2>
              <p className="max-w-[900px] text-slate-300 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Join Wayne Sletcher&apos;s English learning program and transform your language skills.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="#phonics">
                <Button size="lg" className="bg-white text-slate-800 hover:bg-slate-200">
                  Start with Phonics
                </Button>
              </Link>
              <Link href="/level-1">
                <Button variant="outline" size="lg" className="border-white text-white hover:bg-slate-700">
                  Explore Stories
                </Button>
              </Link>
            </div>
            <div className="mt-6">
              <Link
                href="https://ko-fi.com/waynesletcher"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-md bg-amber-500 px-4 py-2 text-base font-medium text-white hover:bg-amber-600"
              >
                <Coffee className="h-5 w-5" />
                Support This Free Resource
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
