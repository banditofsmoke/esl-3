import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, Award, BookText, ArrowLeft } from "lucide-react"
import Link from "next/link"
import SummarySubmission from "@/components/summary-submission"

interface LevelPageProps {
  params: {
    level: string
  }
}

export default function LevelPage({ params }: LevelPageProps) {
  const levelInfo = {
    beginner: {
      title: "Beginner Level",
      description: "Perfect for those starting their English journey",
      icon: <BookOpen className="h-10 w-10 text-slate-800" />,
      timeframe: "6 months program",
      content:
        "This beginner-level text is designed to introduce basic vocabulary and simple sentence structures. It focuses on everyday situations and common expressions to help you build a strong foundation in English.",
    },
    intermediate: {
      title: "Intermediate Level",
      description: "For those with basic English knowledge looking to improve",
      icon: <BookText className="h-10 w-10 text-slate-800" />,
      timeframe: "3 months program",
      content:
        "This intermediate-level text challenges you to expand your vocabulary and work with more complex sentence structures. It introduces nuanced expressions and varied contexts to enhance your English proficiency.",
    },
    advanced: {
      title: "Advanced Level",
      description: "For fluent speakers aiming for mastery",
      icon: <Award className="h-10 w-10 text-slate-800" />,
      timeframe: "6 weeks program",
      content:
        "This advanced-level text explores sophisticated language use, including idiomatic expressions, cultural references, and academic vocabulary. It's designed to refine your English to near-native proficiency through critical analysis and nuanced understanding.",
    },
  }

  const level = params.level as keyof typeof levelInfo
  const info = levelInfo[level] || levelInfo.beginner

  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <Link href="/#start-learning" className="mb-8 inline-flex items-center gap-2 text-slate-600 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        <span>Back to Levels</span>
      </Link>

      <div className="mb-12 flex items-center gap-4">
        {info.icon}
        <div>
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">{info.title}</h1>
          <p className="text-slate-700">{info.description}</p>
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Reading Module</CardTitle>
              <CardDescription>Read the text below and prepare your summary</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                <p>{info.content}</p>

                {level === "intermediate" || level === "advanced" ? (
                  <div className="mt-4">
                    <p className="font-medium">For additional reading practice:</p>
                    <Link
                      href="https://engoo.com/app/daily-news"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-flex items-center gap-2 rounded-md bg-slate-100 px-4 py-2 text-slate-800 hover:bg-slate-200"
                    >
                      <BookOpen className="h-4 w-4" />
                      <span>Visit Engoo Daily News</span>
                    </Link>
                  </div>
                ) : null}
              </div>
            </CardContent>
          </Card>

          <SummarySubmission level={level} />
        </div>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
              <CardDescription>Track your learning journey</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-sm font-medium">Weekly Summaries</span>
                    <span className="text-sm text-slate-600">0/8</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100">
                    <div className="h-2 w-0 rounded-full bg-slate-800"></div>
                  </div>
                </div>

                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-sm font-medium">Overall Progress</span>
                    <span className="text-sm text-slate-600">0%</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100">
                    <div className="h-2 w-0 rounded-full bg-slate-800"></div>
                  </div>
                </div>

                <div className="rounded-lg bg-slate-50 p-4">
                  <h3 className="mb-2 font-semibold">Program Timeline</h3>
                  <p className="text-sm text-slate-700">{info.timeframe}</p>
                  <p className="mt-2 text-sm text-slate-700">
                    Submit 4-8 summaries weekly to complete the program on time.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Learning Resources</CardTitle>
              <CardDescription>Additional materials to support your learning</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {[
                  { name: "Vocabulary List", href: "#" },
                  { name: "Grammar Guide", href: "#" },
                  { name: "Pronunciation Tips", href: "#" },
                  { name: "Practice Exercises", href: "#" },
                ].map((resource) => (
                  <li key={resource.name}>
                    <Link href={resource.href} className="text-slate-700 hover:text-slate-900 hover:underline">
                      {resource.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
