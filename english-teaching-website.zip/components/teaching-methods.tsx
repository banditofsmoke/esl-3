import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, FileText, MessageSquare, CheckCircle2 } from "lucide-react"

export default function TeachingMethods() {
  return (
    <div className="flex flex-col items-center justify-center space-y-8">
      <div className="space-y-2 text-center">
        <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Teaching Methods</h2>
        <p className="max-w-[900px] text-slate-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
          Wayne&apos;s proven methodology for rapid English fluency.
        </p>
      </div>

      <Tabs defaultValue="sentence" className="w-full max-w-4xl">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="sentence">Sentence Construction</TabsTrigger>
          <TabsTrigger value="paragraph">Paragraph Framework</TabsTrigger>
          <TabsTrigger value="core">Core Elements</TabsTrigger>
        </TabsList>

        <TabsContent value="sentence" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Sentence Construction
              </CardTitle>
              <CardDescription>
                Master the building blocks of English sentences with these five key structures.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {[
                  {
                    title: "S.V",
                    description: "Subject + Verb (foundation of a sentence)",
                  },
                  {
                    title: "S.V.A",
                    description: "Matching Subject and Verb (agreement in number and tense)",
                  },
                  {
                    title: "Obj(n.d) + P",
                    description: "Object + Preposition (complete the action with context)",
                  },
                  {
                    title: "*/Adj/Adv*",
                    description: "Adjectives and Adverbs (enrich detail and description)",
                  },
                  {
                    title: "C1, conj. C2",
                    description: "Linking Clauses (build complexity and flow)",
                  },
                ].map((item, index) => (
                  <Card key={index} className="border-slate-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">{item.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-slate-700">{item.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="paragraph" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                4-Step Paragraph Method
              </CardTitle>
              <CardDescription>A structured approach to reading comprehension and summary writing.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[
                  {
                    step: "Step 1: Read Text",
                    description: "Consume English text to understand the content.",
                    icon: <BookOpen className="h-6 w-6 text-slate-800" />,
                  },
                  {
                    step: "Step 2: Identify Main Ideas",
                    description: "Use the 5 W's (Who, What, Where, When, Why) and 1 H (How).",
                    icon: <CheckCircle2 className="h-6 w-6 text-slate-800" />,
                  },
                  {
                    step: "Step 3: Create",
                    description: "Write a 4-sentence summary based on the text.",
                    subItems: [
                      "Sentence 1: Topic sentence.",
                      "Sentences 2 & 3: Supporting sentences that connect to the main idea.",
                      "Sentence 4: Either an opinion sentence or a conclusion sentence.",
                    ],
                    example: {
                      title: "Example (Snow White Story Arc):",
                      sentences: [
                        'Sentence 1 (Topic): "Snow White\'s journey begins with her struggle against a jealous queen."',
                        'Sentence 2 (Support): "She finds refuge with the seven dwarfs and discovers a new sense of family."',
                        'Sentence 3 (Support): "Her kindness and resilience win the hearts of those around her."',
                        'Sentence 4 (Opinion/Conclusion): "In my view, Snow White\'s story is a timeless tale of hope and redemption."',
                      ],
                    },
                    icon: <FileText className="h-6 w-6 text-slate-800" />,
                  },
                  {
                    step: "Step 4: Seek Feedback",
                    description: "Submit your summary to receive feedback.",
                    icon: <MessageSquare className="h-6 w-6 text-slate-800" />,
                  },
                ].map((item, index) => (
                  <div key={index} className="rounded-lg border p-4">
                    <div className="flex items-start gap-4">
                      <div className="mt-1">{item.icon}</div>
                      <div className="space-y-2">
                        <h3 className="font-bold">{item.step}</h3>
                        <p className="text-slate-700">{item.description}</p>

                        {item.subItems && (
                          <ul className="ml-6 list-disc space-y-1 text-slate-700">
                            {item.subItems.map((subItem, i) => (
                              <li key={i}>{subItem}</li>
                            ))}
                          </ul>
                        )}

                        {item.example && (
                          <div className="mt-4 rounded-lg bg-slate-50 p-4">
                            <h4 className="font-semibold">{item.example.title}</h4>
                            <ul className="ml-6 mt-2 list-disc space-y-1 text-slate-700">
                              {item.example.sentences.map((sentence, i) => (
                                <li key={i}>{sentence}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="core" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5" />
                Three Core Teaching Elements
              </CardTitle>
              <CardDescription>The foundation of Wayne&apos;s teaching methodology.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                {[
                  {
                    title: "Five Rules for Sentence Construction",
                    description: "S.V, S.V.A, Obj(n.d)+P, */Adj/Adv*, C1/conj. C2",
                    icon: <BookOpen className="h-10 w-10 text-slate-800" />,
                  },
                  {
                    title: "Four Step Method to Practice",
                    description: "Consume, Analyse, Create, and Feedback",
                    icon: <FileText className="h-10 w-10 text-slate-800" />,
                  },
                  {
                    title: "Words per Breath and Syllable Management",
                    description: "Control breathing, manage syllables, improve fluency, and enhance rhythm",
                    icon: <MessageSquare className="h-10 w-10 text-slate-800" />,
                  },
                ].map((item, index) => (
                  <Card key={index} className="flex flex-col items-center p-6 text-center">
                    <div className="mb-4">{item.icon}</div>
                    <h3 className="mb-2 text-lg font-bold">{item.title}</h3>
                    <p className="text-slate-700">{item.description}</p>
                  </Card>
                ))}
              </div>

              <div className="mt-8 rounded-lg border bg-slate-50 p-6">
                <h3 className="mb-4 text-xl font-bold">Rapid Fluency Program</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <h4 className="font-semibold">For intermediate to advanced learners:</h4>
                    <p className="text-slate-700">6 weeks to 3 months</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">For beginners:</h4>
                    <p className="text-slate-700">6 months</p>
                  </div>
                </div>
                <div className="mt-4">
                  <h4 className="font-semibold">Features include:</h4>
                  <ul className="ml-6 mt-2 list-disc space-y-1 text-slate-700">
                    <li>Customized lessons tailored to individual goals</li>
                    <li>Regular homework assignments</li>
                    <li>Progress reports</li>
                    <li>Flexible scheduling</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
