"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, SkipForward, SkipBack, Clock, Volume2 } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"

export default function PhonicsChart() {
  const [activeTab, setActiveTab] = useState("chart")
  const [isPracticing, setIsPracticing] = useState(false)
  const [currentWordIndex, setCurrentWordIndex] = useState(0)
  const [timer, setTimer] = useState(0)
  const [speed, setSpeed] = useState(1)
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  // Sample phonics words list
  const phonicsWords = [
    "cat",
    "bat",
    "hat",
    "mat",
    "rat",
    "sat",
    "pat",
    "fat",
    "bed",
    "red",
    "fed",
    "led",
    "wed",
    "shed",
    "sled",
    "bred",
    "pig",
    "big",
    "dig",
    "fig",
    "jig",
    "rig",
    "wig",
    "zig",
    "dog",
    "log",
    "fog",
    "hog",
    "jog",
    "bog",
    "cog",
    "frog",
    "cup",
    "pup",
    "sup",
    "tup",
    "yup",
    "up",
    "duck",
    "luck",
    "ship",
    "chip",
    "dip",
    "hip",
    "lip",
    "nip",
    "rip",
    "sip",
    "shop",
    "chop",
    "hop",
    "mop",
    "pop",
    "top",
    "drop",
    "stop",
    "fish",
    "dish",
    "wish",
    "swish",
    "squish",
    "brush",
    "crush",
    "flush",
  ]

  // Syllable breakdown for each word
  const syllableBreakdown = {
    cat: ["c", "a", "t"],
    bat: ["b", "a", "t"],
    hat: ["h", "a", "t"],
    mat: ["m", "a", "t"],
    rat: ["r", "a", "t"],
    sat: ["s", "a", "t"],
    pat: ["p", "a", "t"],
    fat: ["f", "a", "t"],
    bed: ["b", "e", "d"],
    red: ["r", "e", "d"],
    fed: ["f", "e", "d"],
    led: ["l", "e", "d"],
    wed: ["w", "e", "d"],
    shed: ["sh", "e", "d"],
    sled: ["s", "l", "e", "d"],
    bred: ["b", "r", "e", "d"],
    pig: ["p", "i", "g"],
    big: ["b", "i", "g"],
    dig: ["d", "i", "g"],
    fig: ["f", "i", "g"],
    jig: ["j", "i", "g"],
    rig: ["r", "i", "g"],
    wig: ["w", "i", "g"],
    zig: ["z", "i", "g"],
    dog: ["d", "o", "g"],
    log: ["l", "o", "g"],
    fog: ["f", "o", "g"],
    hog: ["h", "o", "g"],
    jog: ["j", "o", "g"],
    bog: ["b", "o", "g"],
    cog: ["c", "o", "g"],
    frog: ["f", "r", "o", "g"],
    cup: ["c", "u", "p"],
    pup: ["p", "u", "p"],
    sup: ["s", "u", "p"],
    tup: ["t", "u", "p"],
    yup: ["y", "u", "p"],
    up: ["u", "p"],
    duck: ["d", "u", "ck"],
    luck: ["l", "u", "ck"],
    ship: ["sh", "i", "p"],
    chip: ["ch", "i", "p"],
    dip: ["d", "i", "p"],
    hip: ["h", "i", "p"],
    lip: ["l", "i", "p"],
    nip: ["n", "i", "p"],
    rip: ["r", "i", "p"],
    sip: ["s", "i", "p"],
    shop: ["sh", "o", "p"],
    chop: ["ch", "o", "p"],
    hop: ["h", "o", "p"],
    mop: ["m", "o", "p"],
    pop: ["p", "o", "p"],
    top: ["t", "o", "p"],
    drop: ["d", "r", "o", "p"],
    stop: ["s", "t", "o", "p"],
    fish: ["f", "i", "sh"],
    dish: ["d", "i", "sh"],
    wish: ["w", "i", "sh"],
    swish: ["s", "w", "i", "sh"],
    squish: ["s", "qu", "i", "sh"],
    brush: ["b", "r", "u", "sh"],
    crush: ["c", "r", "u", "sh"],
    flush: ["f", "l", "u", "sh"],
  }

  // Start practice session
  const startPractice = () => {
    setIsPracticing(true)
    setCurrentWordIndex(0)
    setTimer(0)

    // Start timer
    if (timerRef.current) {
      clearInterval(timerRef.current)
    }

    timerRef.current = setInterval(() => {
      setTimer((prev) => prev + 0.1)
    }, 100)
  }

  // Stop practice session
  const stopPractice = () => {
    setIsPracticing(false)
    if (timerRef.current) {
      clearInterval(timerRef.current)
      timerRef.current = null
    }
  }

  // Next word
  const nextWord = () => {
    if (currentWordIndex < phonicsWords.length - 1) {
      setCurrentWordIndex((prev) => prev + 1)
    } else {
      // Completed first round
      if (isPracticing) {
        setCurrentWordIndex(0) // Start second round
      }
    }
  }

  // Previous word
  const prevWord = () => {
    if (currentWordIndex > 0) {
      setCurrentWordIndex((prev) => prev - 1)
    }
  }

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [])

  // Get current word and its syllables
  const currentWord = phonicsWords[currentWordIndex]
  const currentSyllables = syllableBreakdown[currentWord as keyof typeof syllableBreakdown] || []

  return (
    <div className="flex flex-col items-center justify-center space-y-8">
      <div className="space-y-2 text-center">
        <Badge className="bg-slate-200 text-slate-800 hover:bg-slate-200">Level 0</Badge>
        <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Phonics Chart</h2>
        <p className="max-w-[900px] text-slate-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
          Master English pronunciation with Wayne&apos;s phonics system. Speed and syllable management are key to
          fluency.
        </p>
      </div>

      <Tabs defaultValue="chart" className="w-full max-w-4xl" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="chart">Phonics Chart</TabsTrigger>
          <TabsTrigger value="practice">Practice Reading</TabsTrigger>
          <TabsTrigger value="syllables">Syllable Management</TabsTrigger>
        </TabsList>

        <TabsContent value="chart" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Complete Phonics Chart</CardTitle>
              <CardDescription>
                Study this chart to understand the relationship between letters and sounds in English.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="w-full rounded-lg border bg-white p-4 shadow-lg">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  width={800}
                  height={600}
                  alt="Phonics Chart"
                  className="rounded-lg"
                />
              </div>
              <div className="mt-6 grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Vowel Sounds</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                      {[
                        "a - /æ/ as in cat",
                        "e - /ɛ/ as in bed",
                        "i - /ɪ/ as in pig",
                        "o - /ɒ/ as in dog",
                        "u - /ʌ/ as in cup",
                        "ai - /eɪ/ as in rain",
                        "ee - /iː/ as in see",
                        "oa - /əʊ/ as in boat",
                        "oo - /uː/ as in moon",
                        "ar - /ɑː/ as in car",
                        "or - /ɔː/ as in for",
                        "er - /ɜː/ as in her",
                      ].map((sound, i) => (
                        <li key={i} className="rounded-md bg-slate-50 p-2 text-sm">
                          {sound}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Consonant Sounds</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                      {[
                        "b - /b/ as in bat",
                        "c - /k/ as in cat",
                        "d - /d/ as in dog",
                        "f - /f/ as in fish",
                        "g - /g/ as in get",
                        "h - /h/ as in hat",
                        "j - /dʒ/ as in jam",
                        "k - /k/ as in kite",
                        "l - /l/ as in leg",
                        "m - /m/ as in man",
                        "n - /n/ as in net",
                        "p - /p/ as in pen",
                      ].map((sound, i) => (
                        <li key={i} className="rounded-md bg-slate-50 p-2 text-sm">
                          {sound}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Button onClick={() => setActiveTab("practice")} className="bg-slate-800 hover:bg-slate-700">
                Start Practice
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="practice" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Practice Reading</CardTitle>
              <CardDescription>
                Read all words on this list TWICE, rapidly. Speed and syllable management are key.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {isPracticing ? (
                  <div className="flex flex-col items-center space-y-8">
                    <div className="flex items-center justify-center rounded-lg bg-slate-50 p-8 text-center">
                      <h3 className="text-5xl font-bold tracking-tight text-slate-800">{currentWord}</h3>
                    </div>

                    <div className="flex w-full items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Clock className="h-5 w-5 text-slate-600" />
                        <span className="font-mono text-lg">{timer.toFixed(1)}s</span>
                      </div>

                      <div className="flex items-center gap-4">
                        <Button variant="outline" size="icon" onClick={prevWord}>
                          <SkipBack className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          className="h-12 w-12 rounded-full bg-slate-800 hover:bg-slate-700"
                          onClick={stopPractice}
                        >
                          <Pause className="h-6 w-6" />
                        </Button>
                        <Button variant="outline" size="icon" onClick={nextWord}>
                          <SkipForward className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="flex items-center gap-2">
                        <Volume2 className="h-5 w-5 text-slate-600" />
                        <div className="w-24">
                          <Slider
                            defaultValue={[1]}
                            min={0.5}
                            max={2}
                            step={0.1}
                            value={[speed]}
                            onValueChange={(value) => setSpeed(value[0])}
                          />
                        </div>
                        <span className="text-sm">{speed.toFixed(1)}x</span>
                      </div>
                    </div>

                    <div className="w-full">
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-sm font-medium">Progress</span>
                        <span className="text-sm text-slate-600">
                          {currentWordIndex + 1}/{phonicsWords.length}
                        </span>
                      </div>
                      <Progress value={((currentWordIndex + 1) / phonicsWords.length) * 100} className="h-2" />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="rounded-lg border bg-slate-50 p-6">
                      <h3 className="mb-4 text-lg font-semibold">Instructions</h3>
                      <ul className="ml-6 list-disc space-y-2 text-slate-700">
                        <li>You will be shown a series of phonics words one at a time</li>
                        <li>Read each word aloud, focusing on correct pronunciation</li>
                        <li>Practice reading quickly while maintaining accuracy</li>
                        <li>Complete the entire list twice for mastery</li>
                        <li>Pay attention to syllable breaks in each word</li>
                      </ul>
                    </div>

                    <div className="grid gap-4 md:grid-cols-4">
                      {phonicsWords.slice(0, 16).map((word, index) => (
                        <div key={index} className="rounded-md border p-2 text-center">
                          {word}
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-center">
                      <Button onClick={startPractice} className="bg-slate-800 hover:bg-slate-700">
                        <Play className="mr-2 h-4 w-4" />
                        Start Reading Practice
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="syllables" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Syllable Management</CardTitle>
              <CardDescription>
                Learn to break words into syllables to improve pronunciation and reading fluency.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="rounded-lg border bg-slate-50 p-6">
                  <h3 className="mb-4 text-lg font-semib old">Why Syllable Management Matters</h3>
                  <p className="text-slate-700">
                    Controlling your breath and managing syllables is crucial for English fluency. It helps you:
                  </p>
                  <ul className="ml-6 mt-2 list-disc space-y-1 text-slate-700">
                    <li>Improve pronunciation accuracy</li>
                    <li>Enhance reading speed</li>
                    <li>Develop natural rhythm and intonation</li>
                    <li>Reduce accent and speak more clearly</li>
                  </ul>
                </div>

                {isPracticing ? (
                  <div className="flex flex-col items-center space-y-8">
                    <div className="flex flex-col items-center justify-center rounded-lg bg-slate-50 p-8 text-center">
                      <h3 className="text-2xl font-medium text-slate-600">Syllable Breakdown</h3>
                      <div className="mt-4 flex items-center gap-2">
                        {currentSyllables.map((syllable, index) => (
                          <div key={index} className="rounded-md bg-slate-200 px-4 py-2 text-2xl font-bold">
                            {syllable}
                          </div>
                        ))}
                      </div>
                      <p className="mt-6 text-4xl font-bold tracking-tight text-slate-800">{currentWord}</p>
                    </div>

                    <div className="flex w-full items-center justify-between">
                      <Button variant="outline" size="icon" onClick={prevWord}>
                        <SkipBack className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        className="h-12 w-12 rounded-full bg-slate-800 hover:bg-slate-700"
                        onClick={stopPractice}
                      >
                        <Pause className="h-6 w-6" />
                      </Button>
                      <Button variant="outline" size="icon" onClick={nextWord}>
                        <SkipForward className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="w-full">
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-sm font-medium">Progress</span>
                        <span className="text-sm text-slate-600">
                          {currentWordIndex + 1}/{phonicsWords.length}
                        </span>
                      </div>
                      <Progress value={((currentWordIndex + 1) / phonicsWords.length) * 100} className="h-2" />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid gap-6 md:grid-cols-2">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg">Single-Syllable Words</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-3 gap-2">
                            {["cat", "dog", "fish", "run", "jump", "stop", "fast", "slow", "big"].map((word, i) => (
                              <div key={i} className="rounded-md bg-slate-50 p-2 text-center">
                                {word}
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg">Multi-Syllable Words</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-2 gap-2">
                            {[
                              { word: "rabbit", syllables: "rab-bit" },
                              { word: "basket", syllables: "bas-ket" },
                              { word: "happen", syllables: "hap-pen" },
                              { word: "window", syllables: "win-dow" },
                              { word: "computer", syllables: "com-pu-ter" },
                              { word: "elephant", syllables: "e-le-phant" },
                            ].map((item, i) => (
                              <div key={i} className="rounded-md bg-slate-50 p-2 text-center">
                                <div className="font-medium">{item.word}</div>
                                <div className="text-xs text-slate-600">{item.syllables}</div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="flex justify-center">
                      <Button onClick={startPractice} className="bg-slate-800 hover:bg-slate-700">
                        <Play className="mr-2 h-4 w-4" />
                        Practice Syllable Management
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
