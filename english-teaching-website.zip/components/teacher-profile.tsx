import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Clock, Award, Users, BookOpen } from "lucide-react"

export default function TeacherProfile() {
  return (
    <div className="flex flex-col items-center justify-center space-y-8">
      <div className="space-y-2 text-center">
        <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About Wayne Sletcher</h2>
        <p className="max-w-[900px] text-slate-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
          Meet your dedicated English teacher with 12 years of experience.
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-[1fr_2fr]">
        <div className="flex flex-col items-center space-y-4">
          <div className="relative h-[250px] w-[250px] overflow-hidden rounded-full">
            <Image src="/placeholder.svg?height=250&width=250" alt="Wayne Sletcher" className="object-cover" fill />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Card className="text-center">
              <CardContent className="pt-6">
                <Clock className="mx-auto h-8 w-8 text-slate-800" />
                <h3 className="mt-2 font-bold">12 Years</h3>
                <p className="text-sm text-slate-600">Experience</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <Users className="mx-auto h-8 w-8 text-slate-800" />
                <h3 className="mt-2 font-bold">500+</h3>
                <p className="text-sm text-slate-600">Students</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <BookOpen className="mx-auto h-8 w-8 text-slate-800" />
                <h3 className="mt-2 font-bold">3</h3>
                <p className="text-sm text-slate-600">Programs</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <Award className="mx-auto h-8 w-8 text-slate-800" />
                <h3 className="mt-2 font-bold">98%</h3>
                <p className="text-sm text-slate-600">Success Rate</p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="pt-6">
              <p className="text-lg leading-relaxed text-slate-700">
                "Hello! I'm Wayne Sletcher, a dedicated and passionate English teacher with 12 years of experience. I
                specialize in personalized instruction, interactive learning, and cultural understanding. My goal is to
                help you achieve fluency and confidence in English, whether you're a beginner or looking to refine your
                skills. With a track record of success and a commitment to tailored learning experiences, I'm here to
                guide you on your English language journey."
              </p>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-bold">Personalized Instruction</h3>
                <p className="text-slate-700">
                  Tailored lessons designed to meet your specific learning needs and goals.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-bold">Interactive Learning</h3>
                <p className="text-slate-700">
                  Engaging activities that make the learning process enjoyable and effective.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-bold">Cultural Understanding</h3>
                <p className="text-slate-700">Learn English within its cultural context for deeper comprehension.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
