import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"
import Link from "next/link"

export default function PricingPlans() {
  return (
    <div className="flex flex-col items-center justify-center space-y-8">
      <div className="space-y-2 text-center">
        <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Pricing Options</h2>
        <p className="max-w-[900px] text-slate-700 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
          Choose the plan that fits your learning needs and goals.
        </p>
      </div>

      <div className="grid w-full gap-6 md:grid-cols-3">
        {[
          {
            title: "Basic Support",
            price: "$100",
            description: "5 lessons (1 week of support)",
            features: [
              "5 one-hour lessons",
              "Basic progress tracking",
              "Email support",
              "Access to learning materials",
            ],
          },
          {
            title: "Premium Support",
            price: "$250",
            description: "15 lessons (3 weeks of support)",
            popular: true,
            features: [
              "15 one-hour lessons",
              "Detailed progress reports",
              "Email and chat support",
              "Customized study materials",
              "Weekly homework review",
            ],
          },
          {
            title: "Elite Support",
            price: "$400",
            description: "30 lessons (6 weeks of support)",
            features: [
              "30 one-hour lessons",
              "Comprehensive progress analysis",
              "24/7 email and chat support",
              "Customized study plan and materials",
              "Weekly one-on-one progress review",
              "Priority scheduling",
            ],
          },
        ].map((plan, index) => (
          <Card key={index} className={`flex flex-col ${plan.popular ? "border-slate-800 shadow-lg" : ""}`}>
            {plan.popular && (
              <div className="absolute right-4 top-0 -translate-y-1/2 rounded-full bg-slate-800 px-3 py-1 text-xs font-medium text-white">
                Popular
              </div>
            )}
            <CardHeader>
              <CardTitle>{plan.title}</CardTitle>
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-bold">{plan.price}</span>
                <span className="text-slate-600">for {plan.description}</span>
              </div>
              <CardDescription>
                Perfect for {index === 0 ? "beginners" : index === 1 ? "intermediate learners" : "advanced students"}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-2">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-slate-800" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Link href="/register" className="w-full">
                <Button className={`w-full ${plan.popular ? "bg-slate-800 hover:bg-slate-700" : ""}`}>
                  Get Started
                </Button>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
