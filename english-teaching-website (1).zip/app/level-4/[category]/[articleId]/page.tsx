import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, BookOpen, Share2, MessageSquare } from "lucide-react"
import SummarySubmission from "@/components/summary-submission"
import { notFound } from "next/navigation"

// Import the categories data
import { categories } from "../../../data/level-4-content"

export default function ArticlePage({
  params,
}: {
  params: { category: string; articleId: string }
}) {
  const { category: categoryId, articleId } = params

  // Find the category
  const category = categories.find((cat) => cat.id === categoryId)

  if (!category) {
    notFound()
  }

  // Find the article in the category
  const article = category.articles.find((art) => art.id === articleId)

  if (!article) {
    notFound()
  }

  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <Link href="/level-4" className="mb-8 inline-flex items-center gap-2 text-slate-600 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" />
        <span>Back to Level 4 Resources</span>
      </Link>

      <div className="mb-8 flex flex-col gap-2">
        <div className="flex flex-wrap items-center gap-2">
          <Badge className="bg-slate-200 text-slate-800 hover:bg-slate-200">Level 4</Badge>
          <Badge className="bg-slate-100 text-slate-800 hover:bg-slate-100">{category.title}</Badge>
          {article.tags.map((tag, index) => (
            <Badge key={index} variant="outline">
              {tag}
            </Badge>
          ))}
        </div>
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">{article.title}</h1>
        <p className="text-slate-600">Reading time: {article.readingTime}</p>
      </div>

      <div className="grid gap-8 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Article
              </CardTitle>
              <CardDescription>{article.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                {article.content ? (
                  article.content
                ) : (
                  <>
                    <p>This article is coming soon. Please check back later for the full content.</p>

                    <h2>Introduction</h2>
                    <p>
                      Welcome to this article on {article.title}. This is a placeholder text that will be replaced with
                      the actual content.
                    </p>

                    <h2>Key Concepts</h2>
                    <p>
                      In this article, we'll explore important concepts related to {article.title.toLowerCase()}. The
                      full content will include detailed explanations, examples, and practical advice.
                    </p>

                    <h3>Why This Matters</h3>
                    <p>
                      Understanding {article.title.toLowerCase()} is important for high school students because it
                      prepares you for future academic and professional challenges.
                    </p>

                    <h2>Conclusion</h2>
                    <p>
                      Thank you for your interest in this topic. The complete article will be available soon with
                      comprehensive information on {article.title.toLowerCase()}.
                    </p>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          <SummarySubmission level="4" />
        </div>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Key Concepts</CardTitle>
              <CardDescription>Essential terms and ideas from this article</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="rounded-lg border p-3">
                  <div className="font-medium">Concept 1</div>
                  <div className="text-sm text-slate-600">
                    Description of the first key concept related to {article.title}.
                  </div>
                </li>
                <li className="rounded-lg border p-3">
                  <div className="font-medium">Concept 2</div>
                  <div className="text-sm text-slate-600">
                    Description of the second key concept related to {article.title}.
                  </div>
                </li>
                <li className="rounded-lg border p-3">
                  <div className="font-medium">Concept 3</div>
                  <div className="text-sm text-slate-600">
                    Description of the third key concept related to {article.title}.
                  </div>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Discussion Questions</CardTitle>
              <CardDescription>Think critically about these aspects</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="rounded-lg border p-3">
                  <p className="text-sm text-slate-700">Question 1 related to {article.title}?</p>
                </li>
                <li className="rounded-lg border p-3">
                  <p className="text-sm text-slate-700">Question 2 related to {article.title}?</p>
                </li>
                <li className="rounded-lg border p-3">
                  <p className="text-sm text-slate-700">Question 3 related to {article.title}?</p>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Further Learning</CardTitle>
              <CardDescription>Resources to explore this topic further</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="rounded-lg border p-3">
                  <div className="font-medium">Resource 1</div>
                  <div className="text-sm text-slate-600 mb-2">
                    Description of the first resource related to {article.title}.
                  </div>
                  <a
                    href="#"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-medium text-slate-800 hover:underline"
                  >
                    Visit Website →
                  </a>
                </li>
                <li className="rounded-lg border p-3">
                  <div className="font-medium">Resource 2</div>
                  <div className="text-sm text-slate-600 mb-2">
                    Description of the second resource related to {article.title}.
                  </div>
                  <a
                    href="#"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-medium text-slate-800 hover:underline"
                  >
                    Visit Website →
                  </a>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Link href={`/level-4/${categoryId}`} className="w-full">
                <Button variant="outline" className="w-full">
                  All {category.title} Articles
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Share2 className="h-5 w-5" />
                Share This Article
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                  Facebook
                </Button>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                    <rect width="4" height="12" x="2" y="9"></rect>
                    <circle cx="4" cy="4" r="2"></circle>
                  </svg>
                  LinkedIn
                </Button>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line>
                  </svg>
                  Instagram
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Feedback
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-700 mb-4">Was this article helpful to you?</p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  Very Helpful
                </Button>
                <Button variant="outline" size="sm">
                  Somewhat Helpful
                </Button>
                <Button variant="outline" size="sm">
                  Not Helpful
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
