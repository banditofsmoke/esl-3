import { GraduationCap, Brain, Lightbulb, Briefcase, Code } from "lucide-react"
import { lifeSkillsArticles } from "./level-4-life-skills"
import { careerReadinessArticles } from "./level-4-career-readiness"
import { codingTechArticles } from "./level-4-coding-tech"
import type React from "react"

// Helper function to create article content
const createArticleContent = (content: React.ReactNode) => content

// College Prep Articles
const collegePrep = [
  {
    id: "college-application",
    title: "Navigating the College Application Process",
    description:
      "A comprehensive guide to researching schools, preparing applications, and writing compelling personal statements.",
    tags: ["Applications", "Essays", "Planning"],
    readingTime: "15 minutes",
    content: createArticleContent(
      <>
        <h2>Introduction: The Journey to College</h2>
        <p>
          The college application process can feel like navigating a complex maze with no clear map. With thousands of
          colleges and universities, each with their own requirements, deadlines, and expectations, it's easy to feel
          overwhelmed. However, with proper planning, research, and organization, you can transform this potentially
          stressful experience into an opportunity for self-discovery and growth.
        </p>
        {/* Rest of the content omitted for brevity */}
      </>,
    ),
  },
  {
    id: "scholarship-guide",
    title: "Finding and Securing Scholarships",
    description:
      "Strategies for identifying scholarship opportunities and crafting standout applications to fund your education.",
    tags: ["Financial Aid", "Scholarships", "Essays"],
    readingTime: "13 minutes",
  },
  {
    id: "college-essays",
    title: "Writing Powerful College Essays",
    description:
      "Techniques for crafting authentic, compelling personal statements that showcase your unique qualities and experiences.",
    tags: ["Writing", "Personal Statement", "Admissions"],
    readingTime: "12 minutes",
  },
  {
    id: "college-interviews",
    title: "Acing College Interviews",
    description:
      "Preparation strategies and tips for making a positive impression during college admissions interviews.",
    tags: ["Interviews", "Communication", "Preparation"],
    readingTime: "10 minutes",
  },
  {
    id: "college-success",
    title: "First-Year College Success Strategies",
    description:
      "Essential advice for transitioning to college life, from time management to building relationships with professors.",
    tags: ["Transition", "Study Skills", "Independence"],
    readingTime: "14 minutes",
  },
  {
    id: "major-selection",
    title: "Choosing the Right Major",
    description: "A framework for aligning your academic path with your interests, strengths, and career aspirations.",
    tags: ["Career Planning", "Decision Making", "Self-assessment"],
    readingTime: "11 minutes",
  },
]

// AI & ML Articles
const aiMlArticles = [
  {
    id: "ai-fundamentals",
    title: "AI Fundamentals: What Everyone Should Know",
    description:
      "An accessible introduction to artificial intelligence, its capabilities, limitations, and impact on society.",
    tags: ["AI Basics", "Technology", "Ethics"],
    readingTime: "12 minutes",
    content: createArticleContent(
      <>
        <h2>Introduction: Understanding AI in Our World</h2>
        <p>
          Artificial Intelligence (AI) has moved from science fiction into our everyday lives, often in ways we don't
          even notice. From the recommendations on your favorite streaming service to the voice assistant on your phone,
          AI technologies are quietly reshaping how we interact with the world. But what exactly is AI, how does it
          work, and what does it mean for your future?
        </p>
        {/* Rest of the content omitted for brevity */}
      </>,
    ),
  },
  {
    id: "ml-explained",
    title: "Machine Learning Explained Simply",
    description:
      "Understanding the core concepts of machine learning without the technical jargon, with real-world examples.",
    tags: ["Machine Learning", "Algorithms", "Data"],
    readingTime: "13 minutes",
  },
  {
    id: "ai-ethics",
    title: "Ethical Considerations in AI",
    description:
      "Exploring the ethical challenges posed by AI technologies and frameworks for responsible development and use.",
    tags: ["Ethics", "Responsibility", "Society"],
    readingTime: "14 minutes",
  },
  {
    id: "ai-career-paths",
    title: "Career Paths in Artificial Intelligence",
    description:
      "Overview of educational pathways and career opportunities in the rapidly growing field of artificial intelligence.",
    tags: ["Careers", "Education", "Skills"],
    readingTime: "11 minutes",
  },
  {
    id: "ai-tools-students",
    title: "AI Tools for Students",
    description:
      "A guide to leveraging AI-powered tools to enhance learning, research, and productivity in academic settings.",
    tags: ["Tools", "Productivity", "Learning"],
    readingTime: "10 minutes",
  },
  {
    id: "future-with-ai",
    title: "Preparing for a Future with AI",
    description:
      "Developing the skills and mindset needed to thrive in a world increasingly shaped by artificial intelligence.",
    tags: ["Future Skills", "Adaptation", "Technology"],
    readingTime: "12 minutes",
  },
]

// Export the categories with their articles
export const categories = [
  {
    id: "life-skills",
    title: "Life Skills",
    icon: <Lightbulb className="h-5 w-5 text-slate-800" />,
    description: "Essential skills for success in life beyond academics",
    articles: lifeSkillsArticles,
  },
  {
    id: "college-prep",
    title: "College Preparation",
    icon: <GraduationCap className="h-5 w-5 text-slate-800" />,
    description: "Guidance for navigating the college application process and succeeding in higher education",
    articles: collegePrep,
  },
  {
    id: "ai-ml-basics",
    title: "AI & Machine Learning",
    icon: <Brain className="h-5 w-5 text-slate-800" />,
    description: "Introduction to artificial intelligence concepts and their real-world applications",
    articles: aiMlArticles,
  },
  {
    id: "career-readiness",
    title: "Career Readiness",
    icon: <Briefcase className="h-5 w-5 text-slate-800" />,
    description: "Preparing for the professional world with essential workplace skills and knowledge",
    articles: careerReadinessArticles,
  },
  {
    id: "coding-tech",
    title: "Coding & Technology",
    icon: <Code className="h-5 w-5 text-slate-800" />,
    description: "Introduction to programming concepts and digital literacy for the modern world",
    articles: codingTechArticles,
  },
]
